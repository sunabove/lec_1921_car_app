package com.carapp;

import java.util.Locale;

public class ComObject {

    public static final Locale locale = Locale.ENGLISH;
	
}
